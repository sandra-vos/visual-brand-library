---
title: Pro-Vital Visual Style
file: projects/pro-vital/config/image-generation/brands/pro-vital/visual-style.md

document_type: Project Reference
layer: Project

version: 1.6.2
status: Active

owner: Pro-Vital
project: Pro-Vital

language:
  system: English
  content: English

reference_type: Brand Guideline
authority: High

scope:
  - All

last_updated: 2026-10-03
---

# Pro-Vital Visual Style

## Purpose

This Reference defines the shared visual language of Pro-Vital.

It describes how the Pro-Vital Brand identity is expressed through imagery, composition, shapes, product presentation and other recurring visual characteristics.

This Reference complements the Brand Guidelines.

The Brand Guidelines define the persistent Brand identity.

This Reference defines how that identity SHOULD be expressed visually.

---

# Visual Character

Pro-Vital visual communication SHOULD feel:

- natural;
- fresh;
- clean;
- approachable;
- energetic;
- trustworthy;
- professional.

The overall visual language SHOULD balance natural health and vitality with a clean, contemporary presentation.

Visual communication SHOULD NOT become overly clinical, sterile or technical.

Visual communication SHOULD also avoid an overly alternative, mystical or spiritual appearance.

---

# Overall Composition

Pro-Vital compositions SHOULD remain clear and visually accessible.

Layouts SHOULD:

- provide sufficient visual breathing room;
- avoid unnecessary visual clutter;
- maintain a clear visual hierarchy;
- combine structured layouts with organic visual elements;
- allow important Products, Subjects or messages to remain visually dominant.

Large areas of whitespace or calm background colour MAY be used to create separation and focus.

Visual compositions MAY alternate between light and more strongly coloured sections when appropriate.


---

# Social Composition and Navigation

For designed Pro-Vital social compositions that combine a text section with photography, the photography SHOULD continue behind the leaf-inspired section divider so that no unintended white strip appears between the divider and the photograph. The divider remains subject to the Framework's Semantic Crop Integrity and Content Safe Zones requirements.

When a Pro-Vital leaf-inspired swirl is used, its successive colour bands MUST form one continuous bundle. Adjacent colours MUST meet directly along shared boundaries, with no white, transparent or background-visible gaps between the bands. Preserve this contact through curves, changes in band width and tapered ends; the swirl MUST NOT read as separated floating strips. This rule applies where a swirl is already part of the resolved design and does not require adding one to every image. Inspect the final export for unintended spaces between its colour bands.

Carousel numbering MUST use one consistent reserved navigation position throughout a series. Unless a specific format requires otherwise, Pro-Vital carousel numbers SHOULD appear in the bottom-right corner in a compact, readable treatment that does not compete with the Content.

# Colour Hierarchy Across Media

Apply the Brand colour hierarchy in `brand-guidelines.md` across photographic, illustrated and mixed-media output. Green/lime remains the primary Brand colour family in the default expression; `illustration-style.md` defines the subordinate role of purple and lilac. A palette or reference showing several permitted colours does not give them equal prominence.

In photography, apply Brand colour choices through appropriate styling, environmental accents and graphical treatment while preserving natural skin tones, food, materials and surroundings. Natural photographic colours are Subject appearance, not an additional graphical Brand palette; Brand alignment MUST NOT require tinting the whole scene green.

White and neutral backgrounds MAY provide calm space and contrast. Applicable Product Category and Audience colours follow `visual-variants.md` and its activation and inheritance rules. The availability of a Variant colour alone does not activate that Variant.

---

# Typography Across Photography and Illustration

Added words, sentences, labels and numbers in photographic, illustrated and infographic output MUST use the same Poppins weight for the same text role. The approved photographic typography is the reference for these weights and text colours. Apply these defaults unless an applicable approved Brand or active Variant override specifies otherwise:

| Text role | Actual Poppins weight |
| --- | --- |
| Main headline or standalone key figure | Bold, 700 |
| Section heading or short group label | SemiBold, 600 |
| Supporting emphasis or navigation | Medium, 500 |
| Explanation, body copy or qualification | Regular, 400 |

Font size and line breaks MAY adapt to the format, available space and information hierarchy; an illustrated medium alone is not a reason to change the resolved weight.

Use the same text-colour roles as photographic output: Secondary Green `#006934` on sufficiently light surfaces, white `#FFFFFF` on sufficiently dark surfaces, and Primary Green `#8ABE23` for emphasis only when the actual background provides sufficient contrast. Additional text colours require an applicable approved Brand or active Variant typography decision. Do not select word or sentence colours from the illustration palette merely because the output is illustrated.

Added letters MUST have crisp font-defined contours and one uniform solid fill per text run. Illustration gradients, watercolor, texture or shading MUST NOT appear inside the letters. Text embedded in approved logos or packaging retains its source appearance.

This rule applies only to the letters themselves. Text panels and label backgrounds, other backgrounds, illustrations and compositions continue to follow their existing design rules, including permitted colour, gradients, transparency, layering and depth. Matching weights and text colours does not require copying a photographic layout or flattening any surface behind the text. Existing contrast, padding, Subject protection, editable-font verification and correction-fidelity requirements remain applicable.

---

# Brand Expression in Photography

Explicit graphical Brand elements are optional, not required.

A photographic image MAY remain entirely photographic when its subject, atmosphere, colour harmony and composition already express the intended Pro-Vital visual character.

Organic shapes, waves, leaf forms, hexagons and other graphical Brand elements MAY be added when they serve a clear compositional or communicative purpose. They SHOULD NOT be added merely to make an otherwise complete photographic image appear more branded.

In standalone photography and generated lifestyle imagery, avoid decorative overlays such as:

- corner ornaments;
- bottom waves or coloured wave bands;
- floating Brand shapes;
- isolated decorative icons;
- other graphical additions that do not improve the composition or communication.

Brand expression SHOULD preferably emerge through the complete image: subject choice, photographic character, atmosphere, colour harmony and composition.

Flowing shapes and wave-like boundaries are primarily layout and graphic-design devices. They MAY be appropriate when the output itself is a designed graphical composition, but SHOULD NOT automatically be overlaid on standalone photography or generated lifestyle imagery.

---

# Organic Visual Language

Organic shapes are a recurring characteristic of the Pro-Vital visual identity.

Visual applications MAY use:

- flowing shapes;
- curved transitions;
- wave-like section boundaries;
- leaf-inspired elements;
- soft organic forms;
- small natural or particle-like decorative elements.

Organic elements SHOULD support the composition rather than dominate it.

They SHOULD contribute to the association with nature, vitality and movement.

---

# Brand Leaf Forms

The leaf forms from the Pro-Vital identity MAY be used individually or together as graphical Brand elements.

Individual leaf forms SHOULD be integrated into a wider abstract graphical composition, for example as layered shapes, patterns, cropped or enlarged forms, illustrations or structured accents.

A single leaf SHOULD NOT normally be added as a freestanding decorative icon, sticker or corner ornament to an otherwise photographic image merely to make it appear branded.

When strong and immediately recognisable Brand expression is desired, the characteristic combination of the three leaf forms from the Pro-Vital logo SHOULD be preferred, preserving their recognisable relationship and overall form.

Brand recognition SHOULD primarily emerge from the complete visual system, including colour, shape language, composition and imagery, rather than from an isolated Brand element.

---

# Geometric Elements

Geometric shapes MAY be combined with organic elements.

Hexagonal forms are an established recurring visual element and MAY be used for:

- framing;
- highlighting;
- illustrations;
- visual grouping;
- supporting Brand compositions.

Geometric elements SHOULD remain clean and contemporary.

They SHOULD NOT make the visual identity feel overly technical or rigid.

---

# Photography

Photography SHOULD support the natural and approachable character of Pro-Vital.

Suitable photographic subjects MAY include:

- natural environments;
- plants;
- herbs;
- ingredients;
- raw materials;
- food-related natural sources;
- people where relevant to the content.

Photography SHOULD feel authentic and visually clean.

Natural textures and environments MAY be used to provide context and depth.

Photography SHOULD NOT feel excessively staged, artificial or disconnected from the Subject being communicated.

---

# Geographic and Environmental Context

When photography or generated imagery contains a recognisable everyday environment and the Content does not require a specific location, the setting SHOULD feel geographically plausible for the Netherlands or the neighbouring Northwestern European region.

Suitable environmental character MAY draw from the Netherlands, Belgium, northern Germany or Denmark. The intention is geographic plausibility rather than explicit national symbolism.

Everyday environments SHOULD generally favour:

- flat or gently varying landscapes;
- vegetation and weather plausible for Northwestern Europe;
- architecture, streets, gardens and public spaces credible for the region;
- interiors and lifestyle settings that do not imply an obviously unrelated geographic location.

Visuals SHOULD avoid prominent features that make an ordinary Pro-Vital lifestyle scene feel clearly located elsewhere, such as dramatic mountain ranges, Mediterranean scenery or distinctly non-European suburban environments, unless the Content or Visual Objective requires such a location.

The setting SHOULD NOT become stereotypically Dutch merely to establish location. Windmills, canals, bicycles or other national motifs are not required unless they meaningfully support the Content.

Explicit Content requirements take precedence over this default geographic context.

---

# Nature and Ingredients

Natural ingredients and source materials MAY play a prominent role in Pro-Vital visual communication.

Ingredients MAY be shown:

- individually;
- grouped together;
- surrounding a Product;
- behind or beside Product packaging;
- as part of a wider natural composition.

Ingredient imagery SHOULD have a meaningful relationship to the represented Product or Subject.

Ingredients MUST NOT be added solely for decorative purposes when doing so could create a misleading association with a Product.

---

# Product Presentation

Physical Products SHOULD be represented using approved Product Visual Assets whenever available.

Product packaging MAY be:

- displayed independently;
- grouped with related Products;
- combined with relevant ingredients;
- integrated into photographic compositions;
- combined with graphical or organic elements.

Product presentation SHOULD remain clean and recognisable.

Packaging SHOULD remain sufficiently visible to preserve Product recognition.

Approved Product renders SHOULD be preferred over reconstructed or generated packaging when available.

When a Product-led composition would otherwise feel excessively empty, an approved Product render MAY be placed in a quiet, credible lifestyle environment. The surface, perspective, scale, contact shadow and lighting MUST make the Product feel physically integrated while keeping the packaging unaltered and clearly recognisable.

AI-generated visuals MUST NOT alter the appearance, text, proportions or identifying characteristics of approved Product packaging.

---

# Product Groups

Multiple Products MAY be presented together when communicating:

- the Pro-Vital range;
- related Products;
- a Product family;
- a broader Product category.

Product groups SHOULD maintain sufficient spacing and hierarchy to prevent the composition from becoming visually crowded.

Individual packaging SHOULD remain recognisable where practical.

---

# Illustration Style

Illustrations MAY be used alongside photography and Product imagery.

Illustrations SHOULD generally be:

- clean;
- contemporary;
- accessible;
- simplified rather than highly detailed;
- visually consistent with the broader Pro-Vital identity.

Illustrations MAY combine geometric and organic elements.

For Pro-Vital icons, infographic illustrations and supporting vector-style artwork, the more specific rules in `illustration-style.md` MUST be applied. That Reference defines the approved illustration palette, shape language, gradient behaviour, depth, icon construction and rejection criteria.

For infographics, `infographic-style.md` MUST also be applied. It defines information relationships, infographic patterns, semantic composition, hierarchy and infographic-specific QA before illustration styling is applied.

Illustrations SHOULD support explanation or visual storytelling rather than add unnecessary decoration.

Highly cartoon-like, childish or overly complex illustration styles SHOULD be avoided unless explicitly required by the intended audience or application.

---

# Combination of Visual Media

Pro-Vital MAY combine:

- photography;
- Product renders;
- illustration;
- icons;
- geometric shapes;
- organic shapes;
- graphical accents.

Mixed-media compositions SHOULD feel intentional and cohesive.

Different visual media SHOULD NOT compete for attention without a clear hierarchy.

---

# Use of People

People MAY appear when they meaningfully support the Subject or message.

People SHOULD be represented in a natural, approachable and credible way.

Lifestyle imagery SHOULD support the intended context without relying on exaggerated expressions or unrealistic representations of health and wellbeing.

People SHOULD NOT be used merely as generic decoration when another visual Subject would communicate the message more effectively.

---

# Space and Backgrounds

Clean backgrounds and sufficient negative space are characteristic of the Pro-Vital visual language.

Backgrounds MAY use:

- white;
- light neutral tones;
- Brand colours;
- applicable Visual Variant colours;
- photography;
- subtle graphical elements.

Backgrounds SHOULD preserve readability and visual hierarchy.

Strong backgrounds SHOULD be balanced with simpler foreground compositions.

---

# Visual Depth

Visuals MAY create depth by combining foreground and background elements.

Suitable techniques include:

- overlapping Product and ingredient imagery;
- layered organic shapes;
- partial framing;
- foreground natural elements;
- subtle graphical accents.

Depth SHOULD remain controlled.

Heavy visual effects, excessive layering or unnecessary decoration SHOULD be avoided.

---

# Visual Energy

Pro-Vital visuals MAY communicate vitality and movement through:

- flowing shapes;
- directional compositions;
- natural growth forms;
- particles or small graphical elements;
- dynamic placement of supporting elements.

Movement SHOULD remain controlled and purposeful.

The visual identity SHOULD feel energetic without becoming chaotic.

---

# Relationship to Brand Guidelines

All visual output inherits the Pro-Vital Brand Guidelines.

This includes the persistent Brand identity defined there.

This Reference MUST NOT redefine:

- Brand colours;
- typography;
- logo rules;
- Brand Mark rules.

Where Brand identity requirements conflict with this Reference, the Brand Guidelines take precedence unless an applicable Visual Variant explicitly defines valid override behaviour.

---

# Relationship to Visual Variants

Visual Variants MAY introduce additional visual characteristics for specific Project contexts.

A Visual Variant using `extend` MAY add visual characteristics while preserving this shared Visual Style.

A Visual Variant using `override` MAY replace explicitly defined visual values where permitted by the Visual Standard.

Visual Variants SHOULD preserve the recognisable overall character of Pro-Vital unless an explicit override requires otherwise.

---

# Relationship to Visual Subjects

Visual Subjects MAY provide more specific visual guidance for individual Products, services, concepts or other visually identifiable Subjects.

Subject-specific guidance SHOULD build upon this shared Visual Style.

A Visual Subject MUST NOT duplicate general visual guidance already defined by this Reference.

---

# Relationship to Visual Assets

Approved Visual Assets provide source material for implementing this Visual Style.

Visual Assets MAY include:

- Product renders;
- Product photography;
- ingredient photography;
- lifestyle photography;
- illustrations;
- icons;
- approved visual examples.

Visual Assets MUST remain separate from this Reference.

---

# Restrictions

Unless explicitly defined by another applicable Visual Reference, Pro-Vital visuals SHOULD avoid:

- excessive visual clutter;
- overly dark or heavy compositions;
- excessively clinical presentation;
- mystical or spiritual visual language;
- highly artificial stock-photo aesthetics;
- exaggerated health imagery;
- unnecessary decorative ingredients;
- distorted or reconstructed Product packaging;
- excessive use of visual effects;
- inconsistent combinations of unrelated visual styles.

---

# Guiding Principle

> Express Pro-Vital through a fresh, natural and contemporary visual language that combines clarity, vitality and trustworthy Product presentation.
