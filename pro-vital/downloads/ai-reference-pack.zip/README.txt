Pro-Vital — AI reference pack

This archive is generated automatically from the GitHub source of truth.
Extract the ZIP and upload brand.json, manifest.json and the individual visual files to the AI chat; supply the visuals as image inputs.
brand.json embeds the complete authoritative visual guidance from the repository; read every guidance.documents entry.
The same source documents are included unchanged in guidance/. Their inheritance rules take precedence over display summaries.
This visual-only pack does not replace the Framework workflow, Project requirements or compliance sources.
manifest.json records the Git revision, document versions, original source paths and SHA-256 hashes.
Check these against the active repository before production. A different commit alone does not prove the Brand files changed.
Source revision: 4f7a7690cd735eb7cca15ccf80abcc51d50c365e
Inputs match revision: true
