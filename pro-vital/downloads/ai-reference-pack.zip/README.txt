Pro-Vital — AI reference pack

This archive is generated automatically from the GitHub source of truth.
Extract the ZIP and upload the individual visual files to the AI chat so the model receives them as image inputs.
brand.json contains the public visual identity rules that accompany the assets.
